from base64 import b64decode
from selenium import webdriver
from time import sleep, strftime
from datetime import datetime, timedelta
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

def decrypt(encryption):
    encryption = b64decode(encryption.encode())
    for i in range(10):
        encryption = b64decode(encryption.decode().encode())
    return(encryption.decode())
def currentDate():
	date = strftime("%m/%d")
	w_dict = {'0': '日', '1': '一', '2': '二', '3': '三', '4': '四', '5': '五', '6': '六'}
	if date[0] == '0':
		date = date[1:]
	if date[-2] == '0':
		date = date.replace('0', '')
	return(date + ';' + w_dict[strftime("%w")])
def converter(str):
	if str[0] == '0':
		return(str[1])
	return(str)
def login_redmine(username, passwd):
	driver.find_element_by_id('username').send_keys(username)
	driver.find_element_by_id('password').send_keys(decrypt(passwd))
	driver.find_element_by_name('login').click()
	sleep(5)

try:
	while(1):
		print('Exit: ctrl + c')
		e_count = input('Please input drive erase count: ')
		if e_count.isdigit():
			break
		else:
			print('Invalid drive erase count number')
except KeyboardInterrupt:
	raise SystemExit

weekday = strftime('%w')
yd, bd = datetime.today() - timedelta(days=1), datetime.today() - timedelta(days=2)
ym1, yd2 = converter(yd.strftime('%m')), converter(yd.strftime('%d'))
bm1, bm2 = converter(bd.strftime('%m')), converter(bd.strftime('%d'))
yesterday, beforeday = '{0}/{1}'.format(ym1, yd2), '{0}/{1}'.format(bm1, bm2)

comment1 = '\n{0} ({1}) (RAID 0：Continuous Recording)'.format(currentDate().split(';')[0], currentDate().split(';')[1])
try:
	with open('Comment.txt') as crf:
		data = crf.read().split('#\n')
	un, pw = data[0].split('_')[0].replace('\n', ''), data[0].split('_')[1].replace('\n', '')
	if weekday == '1':
		comment2 = '\n' + data[1].format(e_count, beforeday, yesterday)
	else:
		comment2 = '\n' + data[2].format(e_count)
except:
	pass
	un, pw = 'blake.liou', 'YTA4MDI4MTIwMA=='
	if weekday == '1':
		comment2 = """
1. 64 ch 錄影資料正常沒有斷檔 - Pass
2. SATADOM erase count: {0}
註: 僅確認 {1}、{2} 二日的錄影資料
(因硬碟容量限制，最多只能保存三日的錄影資料)""".format(e_count, beforeday, yesterday)
	else:
		comment2 = """
1. 64 ch 錄影資料正常沒有斷檔 - Pass
2. SATADOM erase count: {}""".format(e_count)

driver = webdriver.Chrome(executable_path='chromedriver.exe')
driver.get('http://dqa02/issues/63954')
print(driver.title + ' has been connected')

login_redmine(un, pw)
driver.find_element_by_xpath('//*[@class="icon icon-edit"]').click()
sleep(3)
print('Paste below comment to Rich Text Editor:\n' + comment1 + '\n' + comment2)

editor = driver.find_element_by_xpath('//*[@title="Rich Text Editor, issue_notes"]')
editor.send_keys(comment1)
editor.send_keys(Keys.HOME)
editor.send_keys(Keys.BACK_SPACE)
editor.send_keys(Keys.CONTROL,'a')
editor.send_keys(Keys.CONTROL,'b')
editor.send_keys(Keys.END)
editor.send_keys(Keys.ENTER)
editor.send_keys(Keys.CONTROL,'b')
editor.send_keys(comment2)

sleep(1)
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
sleep(1)
driver.find_element_by_xpath('//*[@value="Submit"]').click()
sleep(1)
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
sleep(5)
driver.get("http://rd1-1/redmine/issues/26082/time_entries/new")
login_redmine(un, pw)
driver.find_element_by_id('time_entry_hours').send_keys('0.5')
driver.find_element_by_id('time_entry_comments').send_keys('NR9681 穩定性測試觀察與紀錄')
Select(driver.find_element_by_id('time_entry_activity_id')).select_by_value("15")
sleep(1)
driver.find_element_by_xpath('//*[@value="Create"]').click()
sleep(1)
driver.get("http://rd1-1/redmine/work_time/index?day=12&month=1&prj=false&user=711&year=2018")
sleep(5)
driver.quit()
