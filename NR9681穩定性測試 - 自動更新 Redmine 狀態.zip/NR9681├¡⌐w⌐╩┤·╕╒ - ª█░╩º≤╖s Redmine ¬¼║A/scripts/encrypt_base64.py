from os import remove
from msvcrt import getch
from getpass import getpass
from base64 import b64encode, b64decode

def encrypt(pas):
    pas = b64encode(passwd.encode())
    for i in range(10):
        pas = b64encode(pas.decode().encode())
    return(pas.decode())
def decrypt(encryption):
    encryption = b64decode(encryption.encode())
    for i in range(10):
        encryption = b64decode(encryption.decode().encode())
    return(encryption.decode())

print('Exit: ctrl + c')
try:
    while(True):
        passwd = getpass('Encrypt password, Enter your passord: ')
        if passwd:
            if passwd == 'decryption':
                while(True):
                    enpas = input('Enter encrypted password: ')
                    if enpas:
                        try:
                            print('password: ' + decrypt(enpas))
                            getch()
                            raise SystemError
                        except SystemError:
                            raise SystemExit(0)
                        except:
                            pass
                    print('ERROR: invalid encrypted password.')
            try:
                remove('encryption.txt')
            except:
                pass
            pas = encrypt(passwd)
            print('encryption: \n' + pas)
            with open('encryption.txt', 'w') as wf:
                wf.write('encryption: \n' + pas)
        else:
            print('ERROR: invalid password.')
except KeyboardInterrupt:
    pass
