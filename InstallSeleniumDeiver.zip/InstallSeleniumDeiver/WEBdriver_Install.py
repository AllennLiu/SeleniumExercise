import getPythonPath
from re import search
from zipfile import ZipFile
from os import mkdir, environ, listdir
from os.path import join, isfile, isdir, basename, dirname

def findKey(key):
	tmpList = []
	envList = environ['PATH'].split(';')
	for each_path in envList:
		if search(key, each_path):
			tmpList.append(each_path)
	tmpPath = tmpList[0].replace('s\\','s')
	if 'Python' not in basename(tmpPath):
		return(dirname(tmpPath))
	return(tmpPath)
def install(webdriver):
	if isfile(webdriver):
		pythonPath = getPythonPath.getPythonPath()
		print('Python installed in:' + pythonPath)
		driverPath = join(pythonPath, 'driver')
		if not isdir(driverPath):
			mkdir(driverPath)
		num = len(listdir(driverPath))
		with ZipFile(webdriver) as zipf:
			zipf.extractall(driverPath)
		if len(listdir(driverPath)) > num:
			print('WebDriver has been installed complete.')
		else:
			print('WebDriver already exists then replace it.')
	else:
		print('webdriver not found')
print("""
Choose webdriver below listed to install.

[1] Chrome
[2] IE - x86
[3] IE - x64
[4] Firefox - x86
[5] Firefox - x64

Exit: Ctrl + C
""")
try:
	while(1):
		opt = input("Select option: ")
		if opt == '1':
			install('drivers//chromedriver_win32.zip')
			break
		elif opt == '2':
			install('drivers//IEDriverServer_x64_3.8.0.zip')
			break
		elif opt == '3':
			install('drivers//geckodriver-v0.19.1-win32.zip')
			break
		elif opt == '4':
			install('drivers//geckodriver-v0.19.1-win64.zip')
			break
		elif opt == '5':
			install('drivers//IEDriverServer_Win32_3.8.0.zip')
			break
		else:
			print('ERROR: Invalid option')
except KeyboardInterrupt:
	pass