from sys import path
from re import search

def getPythonPath():
	for each_path in path:
		if search('Python\d+', each_path.split('\\')[-1]):
			return(each_path)