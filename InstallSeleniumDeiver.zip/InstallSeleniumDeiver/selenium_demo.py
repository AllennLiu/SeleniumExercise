import getPythonPath
from sys import path
from os.path import join
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 驅動網頁
driver = webdriver.Chrome(executable_path=join(getPythonPath.getPythonPath(), 'driver\\chromedriver.exe'))
driver.get("http://www.yahoo.com.tw")
print(driver.title.encode('utf-8'))

# 控制網頁
inputElement = driver.find_element_by_name("p")
inputElement.send_keys("Python")
inputElement.submit()

try:
	# 直到標題有 cheese
	WebDriverWait(driver, 10).until(EC.title_contains("Python"))

	# 顯示標題，可看到 cheese
	print(driver.title.encode('utf-8'))
except TimeoutException:
	print('time out')
finally:
	driver.quit()